import { createClient } from "npm:@supabase/supabase-js@2";
import { fail } from "../_shared/http.ts";

const enc = new TextEncoder();
async function verifyState(state: string) {
  const [payload, signature] = state.split(".");
  const secret = Deno.env.get("OAUTH_STATE_SECRET");
  if (!payload || !signature || !secret) return null;
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  const sig = Uint8Array.from(atob(signature), c => c.charCodeAt(0));
  if (!await crypto.subtle.verify("HMAC", key, sig, enc.encode(payload))) return null;
  try { const obj = JSON.parse(atob(payload)); return obj.exp > Date.now() ? obj.sub as string : null; } catch { return null; }
}

Deno.serve(async (req) => {
  const url = new URL(req.url);
  const site = Deno.env.get("SITE_URL") ?? "/";
  const code = url.searchParams.get("code");
  const ownerId = await verifyState(url.searchParams.get("state") ?? "");
  if (!code || !ownerId) return Response.redirect(`${site}/?mp=erro`, 303);
  const resp = await fetch("https://api.mercadopago.com/oauth/token", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ client_id: Deno.env.get("MP_CLIENT_ID"), client_secret: Deno.env.get("MP_CLIENT_SECRET"), grant_type: "authorization_code", code, redirect_uri: Deno.env.get("MP_REDIRECT_URI") }),
  });
  if (!resp.ok) return Response.redirect(`${site}/?mp=erro`, 303);
  const token = await resp.json();
  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { error } = await admin.from("mp_seller_tokens").upsert({ owner_id: ownerId, mp_user_id: String(token.user_id), access_token: token.access_token, refresh_token: token.refresh_token, expires_at: new Date(Date.now() + Number(token.expires_in) * 1000).toISOString(), updated_at: new Date().toISOString() });
  if (error) return Response.redirect(`${site}/?mp=erro`, 303);
  return Response.redirect(`${site}/?mp=conectado`, 303);
});
