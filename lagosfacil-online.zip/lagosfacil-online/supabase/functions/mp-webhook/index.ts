import { createClient } from "npm:@supabase/supabase-js@2";
import { validSellerToken } from "../_shared/mercadopago.ts";

async function validSignature(req: Request, dataId: string) {
  const secret = Deno.env.get("MP_WEBHOOK_SECRET");
  const signature = req.headers.get("x-signature");
  const requestId = req.headers.get("x-request-id");
  if (!secret || !signature || !requestId || !dataId) return false;
  const parts = Object.fromEntries(signature.split(",").map(part => part.trim().split("=", 2)));
  if (!parts.ts || !parts.v1) return false;
  const manifest = `id:${dataId};request-id:${requestId};ts:${parts.ts};`;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const digest = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(manifest)));
  const calculated = Array.from(digest, b => b.toString(16).padStart(2, "0")).join("");
  if (calculated.length !== parts.v1.length) return false;
  let mismatch = 0;
  for (let i = 0; i < calculated.length; i++) mismatch |= calculated.charCodeAt(i) ^ parts.v1.charCodeAt(i);
  return mismatch === 0;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const url = new URL(req.url);
  const body = await req.json().catch(() => ({}));
  const paymentId = String(url.searchParams.get("data.id") ?? body?.data?.id ?? "");
  if (!paymentId) return new Response("Missing payment ID", { status: 400 });
  if (!await validSignature(req, paymentId)) return new Response("Invalid signature", { status: 401 });

  const platformToken = Deno.env.get("MP_PLATFORM_ACCESS_TOKEN");
  if (!platformToken) return new Response("Webhook is not configured", { status: 503 });
  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const lookup = await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(paymentId)}`, { headers: { Authorization: `Bearer ${platformToken}` } });
  if (!lookup.ok) return new Response("Payment lookup failed", { status: 502 });
  const first = await lookup.json();
  const bookingId = String(first.external_reference ?? "");
  if (!bookingId) return new Response("Payment has no booking reference", { status: 200 });
  const { data: booking } = await admin.from("bookings").select("id,property_id,gross_amount_brl,properties(owner_id)").eq("id", bookingId).maybeSingle();
  if (!booking) return new Response("Booking not found", { status: 200 });
  const ownerId = (booking as any).properties?.owner_id;
  const sellerToken = await validSellerToken(admin, ownerId);
  if (!sellerToken) return new Response("Seller connection not found", { status: 502 });
  // Confirm the event with the connected seller's token and match it to the reservation.
  const verify = await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(paymentId)}`, { headers: { Authorization: `Bearer ${sellerToken}` } });
  if (!verify.ok) return new Response("Seller payment verification failed", { status: 502 });
  const payment = await verify.json();
  if (String(payment.external_reference) !== booking.id || payment.currency_id !== "BRL" || Math.abs(Number(payment.transaction_amount) - Number(booking.gross_amount_brl)) > 0.01) return new Response("Payment does not match booking", { status: 409 });
  const statusMap: Record<string, string> = { approved: "approved", rejected: "rejected", cancelled: "cancelled", refunded: "refunded" };
  const { error } = await admin.from("bookings").update({ status: statusMap[payment.status] ?? "pending", mp_payment_id: String(payment.id) }).eq("id", booking.id);
  if (error) return new Response("Could not update booking", { status: 500 });
  return new Response("ok", { status: 200 });
});
