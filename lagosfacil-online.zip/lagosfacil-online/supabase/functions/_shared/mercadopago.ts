export async function validSellerToken(admin: any, ownerId: string): Promise<string | null> {
  const { data: seller, error } = await admin.from("mp_seller_tokens")
    .select("access_token,refresh_token,expires_at").eq("owner_id", ownerId).maybeSingle();
  if (error || !seller) return null;
  if (new Date(seller.expires_at).getTime() > Date.now() + 60_000) return seller.access_token;
  const clientId = Deno.env.get("MP_CLIENT_ID"), clientSecret = Deno.env.get("MP_CLIENT_SECRET");
  if (!clientId || !clientSecret || !seller.refresh_token) return null;
  const response = await fetch("https://api.mercadopago.com/oauth/token", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ client_id: clientId, client_secret: clientSecret, grant_type: "refresh_token", refresh_token: seller.refresh_token }),
  });
  if (!response.ok) return null;
  const token = await response.json();
  const expiresAt = new Date(Date.now() + Number(token.expires_in) * 1000).toISOString();
  const { error: saveError } = await admin.from("mp_seller_tokens").update({ access_token: token.access_token, refresh_token: token.refresh_token, expires_at: expiresAt, updated_at: new Date().toISOString() }).eq("owner_id", ownerId);
  return saveError ? null : token.access_token;
}
