import { createClient } from "npm:@supabase/supabase-js@2";
import { fail, json, options } from "../_shared/http.ts";
import { validSellerToken } from "../_shared/mercadopago.ts";

Deno.serve(async (req) => {
  const preflight = options(req); if (preflight) return preflight;
  if (req.method !== "POST") return fail("Método não permitido", 405);
  const auth = req.headers.get("Authorization"); if (!auth) return fail("Entre na sua conta para continuar", 401);
  const url = Deno.env.get("SUPABASE_URL")!;
  const anon = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
  const { data: { user }, error: authError } = await anon.auth.getUser();
  if (authError || !user) return fail("Sessão inválida", 401);
  let body: { propertyId?: string; checkIn?: string; checkOut?: string };
  try { body = await req.json(); } catch { return fail("Dados de reserva inválidos"); }
  if (!body.propertyId || !/^\d{4}-\d\d-\d\d$/.test(body.checkIn ?? "") || !/^\d{4}-\d\d-\d\d$/.test(body.checkOut ?? "")) return fail("Informe o imóvel e as datas da reserva");
  const start = new Date(`${body.checkIn}T00:00:00Z`), end = new Date(`${body.checkOut}T00:00:00Z`);
  const nights = Math.round((end.getTime() - start.getTime()) / 86400000);
  if (!Number.isInteger(nights) || nights < 1 || nights > 30 || start < new Date(new Date().toISOString().slice(0,10) + "T00:00:00Z")) return fail("Escolha datas válidas (1 a 30 noites)");
  const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: property, error: propertyError } = await admin.from("properties").select("id,owner_id,title,price_brl,rental_type,published").eq("id", body.propertyId).eq("published", true).single();
  if (propertyError || !property) return fail("Imóvel indisponível", 404);
  if (property.owner_id === user.id) return fail("Você não pode reservar seu próprio imóvel");
  if (property.rental_type !== "Temporada") return fail("Reservas online estão disponíveis apenas para imóveis de temporada");
  const sellerToken = await validSellerToken(admin, property.owner_id);
  if (!sellerToken) return fail("O anfitrião precisa reconectar o Mercado Pago", 409);
  const gross = Math.round(Number(property.price_brl) * nights * 100) / 100;
  const fee = Math.round(gross * 0.15 * 100) / 100;
  const { data: booking, error: insertError } = await admin.from("bookings").insert({ property_id: property.id, renter_id: user.id, check_in: body.checkIn, check_out: body.checkOut, gross_amount_brl: gross, marketplace_fee_brl: fee }).select("id").single();
  if (insertError || !booking) return fail("Não foi possível iniciar a reserva", 500);
  const site = Deno.env.get("SITE_URL")!;
  const mp = await fetch("https://api.mercadopago.com/checkout/preferences", { method: "POST", headers: { Authorization: `Bearer ${sellerToken}`, "Content-Type": "application/json", "X-Idempotency-Key": booking.id }, body: JSON.stringify({ items: [{ id: property.id, title: property.title, quantity: nights, currency_id: "BRL", unit_price: Number(property.price_brl) }], marketplace_fee: fee, external_reference: booking.id, notification_url: `${url}/functions/v1/mp-webhook`, back_urls: { success: `${site}/?reserva=sucesso`, pending: `${site}/?reserva=pendente`, failure: `${site}/?reserva=erro` }, auto_return: "approved" }) });
  const pref = await mp.json();
  if (!mp.ok || !pref.init_point) { await admin.from("bookings").update({ status: "rejected" }).eq("id", booking.id); return fail("O Mercado Pago não conseguiu criar o checkout. Tente mais tarde.", 502); }
  await admin.from("bookings").update({ mp_preference_id: pref.id }).eq("id", booking.id);
  return json({ checkoutUrl: pref.init_point, bookingId: booking.id });
});
