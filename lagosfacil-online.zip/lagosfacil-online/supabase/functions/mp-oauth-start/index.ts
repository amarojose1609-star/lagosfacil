import { createClient } from "npm:@supabase/supabase-js@2";
import { fail, options } from "../_shared/http.ts";

const enc = new TextEncoder();
async function signedState(userId: string) {
  const secret = Deno.env.get("OAUTH_STATE_SECRET");
  if (!secret) throw new Error("OAuth state secret is not configured");
  const payload = btoa(JSON.stringify({ sub: userId, exp: Date.now() + 10 * 60_000, nonce: crypto.randomUUID() }));
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(payload));
  return `${payload}.${btoa(String.fromCharCode(...new Uint8Array(sig)))}`;
}

Deno.serve(async (req) => {
  const preflight = options(req); if (preflight) return preflight;
  if (req.method !== "POST") return fail("Método não permitido", 405);
  const auth = req.headers.get("Authorization");
  if (!auth) return fail("Entre na sua conta para conectar o Mercado Pago", 401);
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
  const { data: { user }, error } = await sb.auth.getUser();
  if (error || !user) return fail("Sessão inválida", 401);
  const clientId = Deno.env.get("MP_CLIENT_ID");
  const redirectUri = Deno.env.get("MP_REDIRECT_URI");
  if (!clientId || !redirectUri) return fail("OAuth do Mercado Pago ainda não foi configurado", 503);
  const state = await signedState(user.id);
  const url = new URL("https://auth.mercadopago.com/authorization");
  url.search = new URLSearchParams({ client_id: clientId, response_type: "code", platform_id: "mp", redirect_uri: redirectUri, state }).toString();
  return Response.json({ url: url.toString() }, { headers: { ...corsHeaders, "Content-Type": "application/json" } });
});
