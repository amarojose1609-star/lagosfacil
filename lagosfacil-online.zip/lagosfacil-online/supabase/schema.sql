create extension if not exists pgcrypto;
create extension if not exists btree_gist;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  created_at timestamptz not null default now()
);

create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 5 and 120),
  description text not null default '',
  city text not null check (city in ('Araruama','São Pedro da Aldeia','Arraial do Cabo','Armação dos Búzios','Cabo Frio')),
  rental_type text not null check (rental_type in ('Temporada','Fixo')),
  price_brl numeric(12,2) not null check (price_brl > 0),
  bedrooms int not null default 1 check (bedrooms between 1 and 30),
  contact_phone text not null,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.property_photos (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  storage_path text not null,
  sort_order int not null default 0
);

-- Apenas Edge Functions com service role podem ler/escrever tokens de vendedores.
create table if not exists public.mp_seller_tokens (
  owner_id uuid primary key references auth.users(id) on delete cascade,
  mp_user_id text not null,
  access_token text not null,
  refresh_token text not null,
  expires_at timestamptz not null,
  updated_at timestamptz not null default now()
);
alter table public.mp_seller_tokens enable row level security;
revoke all on public.mp_seller_tokens from anon, authenticated;

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id),
  renter_id uuid references auth.users(id) on delete set null,
  check_in date not null,
  check_out date not null,
  gross_amount_brl numeric(12,2) not null check (gross_amount_brl > 0),
  marketplace_fee_brl numeric(12,2) not null check (marketplace_fee_brl >= 0),
  mp_preference_id text,
  mp_payment_id text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','cancelled','refunded')),
  created_at timestamptz not null default now(),
  check (check_out > check_in)
);

-- Evita duas reservas ativas para as mesmas datas. Reservas pendentes precisam ser
-- canceladas manualmente se o comprador abandonar o checkout; expirador automático
-- deve ser configurado antes de operar em produção.
do $$ begin
  alter table public.bookings add constraint no_overlapping_active_bookings
  exclude using gist (property_id with =, daterange(check_in, check_out, '[)') with &&)
  where (status in ('pending','approved'));
exception when duplicate_object then null;
end $$;

alter table public.profiles enable row level security;
alter table public.properties enable row level security;
alter table public.property_photos enable row level security;
alter table public.bookings enable row level security;

create policy "users read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "users edit own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "users create own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);

create policy "published properties are public" on public.properties for select using (published or auth.uid() = owner_id);
create policy "owner creates property" on public.properties for insert to authenticated with check (auth.uid() = owner_id);
create policy "owner edits property" on public.properties for update to authenticated using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "owner deletes property" on public.properties for delete to authenticated using (auth.uid() = owner_id);

create policy "photos for visible properties" on public.property_photos for select using (
  exists (select 1 from public.properties p where p.id = property_id and (p.published or p.owner_id = auth.uid()))
);
create policy "owners manage property photos" on public.property_photos for all to authenticated using (
  exists (select 1 from public.properties p where p.id = property_id and p.owner_id = auth.uid())
) with check (
  exists (select 1 from public.properties p where p.id = property_id and p.owner_id = auth.uid())
);

create policy "renters see own bookings" on public.bookings for select to authenticated using (renter_id = auth.uid());
create policy "owners see bookings of own properties" on public.bookings for select to authenticated using (
  exists (select 1 from public.properties p where p.id = property_id and p.owner_id = auth.uid())
);

-- Explicit API grants: access remains limited by the RLS policies above.
grant usage on schema public to anon, authenticated;
grant select on public.properties, public.property_photos to anon, authenticated;
grant select, insert, update, delete on public.properties to authenticated;
grant insert, update, delete on public.property_photos to authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select on public.bookings to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('property-photos', 'property-photos', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "public can view property photos" on storage.objects for select using (bucket_id = 'property-photos');
create policy "signed in owners upload photos" on storage.objects for insert to authenticated with check (
  bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text
);
create policy "owners update own photos" on storage.objects for update to authenticated using (
  bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text
);
create policy "owners remove own photos" on storage.objects for delete to authenticated using (
  bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text
);
